#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <string>
#include <functional>
#include <algorithm>
template <typename T>
T clamp(T value, T min, T max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}


using namespace std;

const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;
const float PLAYER_SPEED = 300.0f;
const float BULLET_SPEED = 500.0f;
float ENEMY_SPEED = 100.0f;
const float SHOOT_COOLDOWN = 0.5f;


enum class GameState { Menu, Playing, Exit };

struct MenuOption {
    sf::Text text;
    std::function<void()> action;
};


struct MenuButton {
    sf::RectangleShape background;
    sf::Text text;
    std::function<void()> action;
    bool isHovered = false;

    void draw(sf::RenderWindow& window) {
        window.draw(background);
        window.draw(text);
    }

    void checkHover(const sf::Vector2f& mousePos) {
        if (background.getGlobalBounds().contains(mousePos)) {
            if (!isHovered) {
                isHovered = true;
                background.setFillColor(sf::Color(100, 200, 255));
                text.setFillColor(sf::Color::Black);
            }
        }
        else {
            if (isHovered) {
                isHovered = false;
                background.setFillColor(sf::Color(50, 100, 150));
                text.setFillColor(sf::Color::White);
            }
        }
    }
};

void createMenu(sf::RenderWindow& window, sf::Font& font, GameState& gameState, float& musicVolume, float& sfxVolume, int& difficulty) {
    // Background
    sf::RectangleShape background(sf::Vector2f(WINDOW_WIDTH, WINDOW_HEIGHT));
    background.setFillColor(sf::Color(20, 30, 60));

    // Title
    sf::Text title("Space Invaders", font, 60);
    title.setFillColor(sf::Color::Green);
    title.setStyle(sf::Text::Bold);
    title.setOutlineColor(sf::Color::Black);
    title.setOutlineThickness(2);
    title.setPosition(WINDOW_WIDTH / 2 - title.getGlobalBounds().width / 2, 30);

    // Menu buttons
    std::vector<MenuButton> buttons;

    auto createButton = [&](const std::string& label, float yPos, std::function<void()> action) {
        MenuButton button;
        button.background.setSize({ 300, 50 });
        button.background.setFillColor(sf::Color(50, 100, 150));
        button.background.setOutlineColor(sf::Color::White);
        button.background.setOutlineThickness(2);
        button.background.setPosition(WINDOW_WIDTH / 2 - button.background.getSize().x / 2, yPos);

        button.text.setFont(font);
        button.text.setString(label);
        button.text.setCharacterSize(24);
        button.text.setFillColor(sf::Color::White);
        button.text.setPosition(button.background.getPosition().x + button.background.getSize().x / 2 - button.text.getGlobalBounds().width / 2,
            button.background.getPosition().y + 10);

        button.action = action;
        buttons.push_back(button);
        };

    createButton("Start Game", 150, [&]() { gameState = GameState::Playing; });
    createButton("Exit", 400, [&]() { gameState = GameState::Exit; });

    // Difficulty buttons
    sf::Text difficultyLabel("Difficulty", font, 30);
    difficultyLabel.setFillColor(sf::Color::White);
    difficultyLabel.setPosition(WINDOW_WIDTH / 2 - 100, 250);

    std::vector<MenuButton> difficultyButtons;
    std::vector<std::string> difficulties = { "Easy", "Medium", "Hard" };
    for (size_t i = 0; i < difficulties.size(); ++i) {
        createButton(difficulties[i], 300 + i * 60, [&, i]() { difficulty = i; });
    }

    // Volume sliders
    auto createSlider = [&](sf::Text& label, sf::RectangleShape& bar, sf::RectangleShape& knob, const std::string& labelText, float yPos) {
        label.setFont(font);
        label.setString(labelText);
        label.setCharacterSize(20);
        label.setFillColor(sf::Color::White);
        label.setPosition(WINDOW_WIDTH / 2 - 150, yPos - 30);

        bar.setSize({ 200, 10 });
        bar.setFillColor(sf::Color(100, 100, 100));
        bar.setPosition(WINDOW_WIDTH / 2 - 100, yPos);

        knob.setSize({ 20, 30 });
        knob.setFillColor(sf::Color::Green);
        knob.setPosition(bar.getPosition().x + bar.getSize().x / 2 - knob.getSize().x / 2, yPos - 10);
        };

    sf::Text musicLabel, sfxLabel;
    sf::RectangleShape musicBar, musicKnob, sfxBar, sfxKnob;

    createSlider(musicLabel, musicBar, musicKnob, "Music Volume", 500);
    createSlider(sfxLabel, sfxBar, sfxKnob, "SFX Volume", 550);

    while (window.isOpen() && gameState == GameState::Menu) {
        sf::Event event;
        sf::Vector2f mousePos = sf::Vector2f(sf::Mouse::getPosition(window));

        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                gameState = GameState::Exit;
                window.close();
            }

            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                for (auto& button : buttons) {
                    if (button.background.getGlobalBounds().contains(mousePos)) {
                        button.action();
                    }
                }
                for (auto& button : difficultyButtons) {
                    if (button.background.getGlobalBounds().contains(mousePos)) {
                        difficulty = &button - &difficultyButtons[0];
                    }
                }
                if (musicBar.getGlobalBounds().contains(mousePos)) {
                    float volume = (mousePos.x - musicBar.getPosition().x) / musicBar.getSize().x * 100.0f;
                    musicVolume = clamp(volume, 0.0f, 100.0f);
                    musicKnob.setPosition(musicBar.getPosition().x + (musicVolume / 100.0f) * musicBar.getSize().x - musicKnob.getSize().x / 2, musicKnob.getPosition().y);
                }
                if (sfxBar.getGlobalBounds().contains(mousePos)) {
                    float volume = (mousePos.x - sfxBar.getPosition().x) / sfxBar.getSize().x * 100.0f;
                    sfxVolume = clamp(volume, 0.0f, 100.0f);
                    sfxKnob.setPosition(sfxBar.getPosition().x + (sfxVolume / 100.0f) * sfxBar.getSize().x - sfxKnob.getSize().x / 2, sfxKnob.getPosition().y);
                }
            }
        }

        // Hover effect
        for (auto& button : buttons) {
            button.checkHover(mousePos);
        }

        window.clear();
        window.draw(background);
        window.draw(title);

        for (auto& button : buttons) {
            button.draw(window);
        }

        window.draw(difficultyLabel);
        for (auto& button : difficultyButtons) {
            button.draw(window);
        }

        window.draw(musicLabel);
        window.draw(musicBar);
        window.draw(musicKnob);

        window.draw(sfxLabel);
        window.draw(sfxBar);
        window.draw(sfxKnob);

        window.display();
    }
}
////////////////////////////////////////////////////



struct Bullet {
    sf::RectangleShape shape;
};

struct Enemy {
    sf::Sprite sprite;
};

void showStartMenu(sf::RenderWindow& window, sf::Font& font) {
    sf::Text titleText("Space Invaders", font, 50);
    titleText.setFillColor(sf::Color::Green);
    titleText.setPosition(WINDOW_WIDTH / 2 - titleText.getGlobalBounds().width / 2, WINDOW_HEIGHT / 3);

    sf::Text instructionText("Press Enter to Start", font, 30);
    instructionText.setFillColor(sf::Color::White);
    instructionText.setPosition(WINDOW_WIDTH / 2 - instructionText.getGlobalBounds().width / 2, WINDOW_HEIGHT / 2);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
            break;
        }

        window.clear();
        window.draw(titleText);
        window.draw(instructionText);
        window.display();
    }
}

void updateBullets(std::vector<Bullet>& bullets, float dt) {
    for (size_t i = 0; i < bullets.size(); ++i) {
        bullets[i].shape.move(0, -BULLET_SPEED * dt);

        if (bullets[i].shape.getPosition().y < 0) {
            bullets.erase(bullets.begin() + i);
            --i;
        }
    }
}

void updateEnemies(std::vector<Enemy>& enemies, float dt, float& direction) {
    float moveDistance = ENEMY_SPEED * dt * direction;

    for (size_t i = 0; i < enemies.size(); ++i) {
        enemies[i].sprite.move(moveDistance, 0);

        if (enemies[i].sprite.getPosition().x <= 0 ||
            enemies[i].sprite.getPosition().x >= WINDOW_WIDTH - enemies[i].sprite.getGlobalBounds().width) {
            direction *= -1;
            for (size_t j = 0; j < enemies.size(); ++j) {
                enemies[j].sprite.move(0, 10); // Move down when direction changes
            }
            break;
        }
    }
}

void checkBulletEnemyCollisions(std::vector<Bullet>& bullets, std::vector<Enemy>& enemies, int& score, sf::Sound& hitSound, sf::Text& scoreText) {
    for (size_t i = 0; i < bullets.size();) {
        bool hit = false;
        for (size_t j = 0; j < enemies.size();) {
            if (bullets[i].shape.getGlobalBounds().intersects(enemies[j].sprite.getGlobalBounds())) {
                bullets.erase(bullets.begin() + i);
                enemies.erase(enemies.begin() + j);
                hitSound.play();
                score += 10;
                scoreText.setString("Score: " + to_string(score));
                hit = true;
                break;
            }
            else {
                ++j;
            }
        }
        if (!hit) {
            ++i;
        }
    }
}

void checkWinCondition(const std::vector<Enemy>& enemies, int score, sf::RenderWindow& window, sf::Text& scoreText) {
    if (enemies.empty()) {
        scoreText.setString("    You Win!\nFinal Score: " + to_string(score));
        scoreText.setFillColor(sf::Color::Green);
        sf::FloatRect textBounds = scoreText.getGlobalBounds();
        scoreText.setPosition(WINDOW_WIDTH / 2 - textBounds.width / 2, WINDOW_HEIGHT / 2 - textBounds.height / 2);

        window.clear();
        window.draw(scoreText);
        window.display();
        sf::sleep(sf::seconds(3));
        window.close();
    }
}

void checkGameOver(const std::vector<Enemy>& enemies, const sf::Sprite& player, int score, sf::RenderWindow& window, sf::Text& scoreText) {
    for (size_t i = 0; i < enemies.size(); ++i) {
        if (enemies[i].sprite.getPosition().y > WINDOW_HEIGHT - player.getGlobalBounds().height) {
            scoreText.setFillColor(sf::Color::Red);
            scoreText.setString("   Game Over!\nFinal Score: " + to_string(score));
            sf::FloatRect textBounds = scoreText.getGlobalBounds();
            scoreText.setPosition(WINDOW_WIDTH / 2 - textBounds.width / 2, WINDOW_HEIGHT / 2 - textBounds.height / 2);

            window.clear();
            window.draw(scoreText);
            window.display();
            sf::sleep(sf::seconds(3));
            window.close();
            break;
        }
    }
}

int main() {
    sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Space Invaders");
    window.setFramerateLimit(60);

    GameState gameState = GameState::Menu;
    float musicVolume = 50.f, sfxVolume = 50.f;
    int difficulty = 1;

    // Load textures
    sf::Texture playerTexture, enemyTexture, backgroundTexture;
    if (!playerTexture.loadFromFile("player.png") ||
        !enemyTexture.loadFromFile("enemy.png") ||
        !backgroundTexture.loadFromFile("background.png")) {
        return -1;
    }

    // Background setup
    sf::Sprite background;
    background.setTexture(backgroundTexture);

    // Player setup
    sf::Sprite player(playerTexture);
    player.setPosition(WINDOW_WIDTH / 2 - player.getGlobalBounds().width / 2, WINDOW_HEIGHT - player.getGlobalBounds().height - 10);

    // Font and score setup
    sf::Font font;
    if (!font.loadFromFile("alien.ttf")) {
        return -1;
    }
    sf::Text scoreText("Score: 0", font, 20);
    scoreText.setPosition(10, 10);
    int score = 0;

    // Sound setup
    sf::SoundBuffer shootBuffer, hitBuffer;
    if (!shootBuffer.loadFromFile("shoot.mp3") || !hitBuffer.loadFromFile("hit.mp3")) {
        return -1;
    }
    sf::Sound shootSound(shootBuffer);
    sf::Sound hitSound(hitBuffer);

    // Music setup
    sf::Music music;
    if (!music.openFromFile("music.mp3")) {
        return -1;
    }
    music.setLoop(true);
    music.play();

    std::vector<Bullet> bullets;
    std::vector<Enemy> enemies;

    // Enemy setup
    int rows = 4, cols = 8;
    float enemyStartX = 100, enemyStartY = 50, enemySpacing = 60;
    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            Enemy enemy;
            enemy.sprite.setTexture(enemyTexture);
            enemy.sprite.setPosition(enemyStartX + col * enemySpacing, enemyStartY + row * 40);
            enemies.push_back(enemy);
        }
    }

    // Show start menu
    createMenu(window, font, gameState, musicVolume, sfxVolume, difficulty);

    sf::Clock clock;
    float shootTimer = 0.0f;
    float enemyDirection = 1.0f;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }

        float dt = clock.restart().asSeconds();
        shootTimer -= dt;

        // Player movement
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && player.getPosition().x > 0) {
            player.move(-PLAYER_SPEED * dt, 0);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) &&
            player.getPosition().x < WINDOW_WIDTH - player.getGlobalBounds().width) {
            player.move(PLAYER_SPEED * dt, 0);
        }

        // Shooting bullets
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && shootTimer <= 0) {
            Bullet bullet;
            bullet.shape.setSize({ 5, 20 });
            bullet.shape.setFillColor(sf::Color::Red);
            bullet.shape.setPosition(player.getPosition().x + player.getGlobalBounds().width / 2 - 2.5f, player.getPosition().y);
            bullets.push_back(bullet);
            shootSound.play();
            shootTimer = SHOOT_COOLDOWN;
        }

        // Update bullets and enemies
        updateBullets(bullets, dt);
        updateEnemies(enemies, dt, enemyDirection);

        // Check for bullet-enemy collisions
        checkBulletEnemyCollisions(bullets, enemies, score, hitSound, scoreText);

        // Increase difficulty as score increases
        if (score % 50 == 0 && score > 0) {
            ENEMY_SPEED += 0.60f;
        }

        // Check win condition
        checkWinCondition(enemies, score, window, scoreText);

        // Check game over condition
        checkGameOver(enemies, player, score, window, scoreText);

        // Render
        window.clear();
        window.draw(background);
        window.draw(player);

        for (size_t i = 0; i < bullets.size(); ++i) {
            window.draw(bullets[i].shape);
        }

        for (size_t i = 0; i < enemies.size(); ++i) {
            window.draw(enemies[i].sprite);
        }

        window.draw(scoreText);
        window.display();
    }

    return 0;
}
